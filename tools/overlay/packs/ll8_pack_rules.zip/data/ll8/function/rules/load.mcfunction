# The mods' own load functions run in the same tick as this one, in whatever
# order the packs happen to be applied. Waiting a second puts these settings
# last, which is the only ordering that matters here.
schedule function ll8:rules/enforce 20t replace
