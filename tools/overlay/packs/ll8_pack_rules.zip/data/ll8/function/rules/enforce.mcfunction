# The two rules this pack keeps, re-applied every five minutes because both are
# one click or one command away from being undone, and neither is something a
# friend can undo afterwards.

# Mobs do not take the world apart. Alex's Caves reads this rule for the
# Tremorzilla, the Forsaken, the Magnetron and the Nucleeper; vanilla reads it
# for creepers, endermen, ghasts and the rest. It also stops villagers from
# farming, which is the price.
gamerule mobGriefing false

function ll8:rules/fromthefog
schedule function ll8:rules/enforce 6000t replace
